const inicializar = () =>{
    
    let nombre = prompt("Introduza el nombre: ");


}