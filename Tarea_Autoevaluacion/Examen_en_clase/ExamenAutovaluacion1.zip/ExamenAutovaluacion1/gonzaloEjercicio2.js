const add = () =>{
    //Datos del formulario
    let numEmpleado = document.getElementsByTagName("numeroEmpleado").values;
    let dni = document.getElementsByTagName("dni").values;
    let nombre = document.getElementsByTagName("nombre").values;
    let apellidos = document.getElementsByTagName("apellidos").values;

    //Datos de la tabla y de la fila
    let tabla = document.getElementsByTagName("tabla");
    let filaAnterior = tabla.getElementsByTagName("tr")[numEmpleado];

    //Datos del dni
    let dniPosterior=document.createElement("td");
    dniPosterior.appendChild(document.createTextNode(dni));

    //Datos del nombre
    let nombrePosterior=document.createElement("td");
    nombrePosterior.appendChild(document.createTextNode(nombre));

    //Datos de los apellidos
    let apellidosAnterior = document.createElement("td");
    apellidosAnterior.appendChild(document.createElement(apellidos));

    //Fila nueva
    let filaNueva = document.createElement("tr");
    filaNueva.appendChild(numEmpleado);
    filaNueva.appendChild(dniPosterior);
    filaNueva.appendChild(nombrePosterior);
    filaNueva.appendChild(apellidosAnterior);

    //Excepciones si el empleado existe
    let mensaje;
    if(dni==dniPosterior){
        mensaje ="Error, el empleado ya existe"
    }
    else{
        //cambiamos la fila antigua por la nueva
        numEmpleado.parentNode.replaceChild(filaNueva,numEmpleado);
    }


}

const borrar = () =>{

}

const modificar = () =>{

}